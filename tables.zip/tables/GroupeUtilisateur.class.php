<?php 

	class GroupeUtilisateur {
	
		  public $idGroupeUtilisateur; // Clef Primaire
		  public $nomGroupeUtilisateur;
		  public $idDepartement; // Clef secondaire vers Departement
	}
	
?>