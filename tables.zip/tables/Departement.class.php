<?php

	class Departement {

		public $idDepartement; // Clef Primaire
		public $nomDepartement;
	}
	
?>