<?php


	/*class Commentaire {
	
		public $idCommentaire; // Clef Primaire
		public $commentaire;
		public $datecommentaire;
		public $idUtilisateur; // Clef étrangère vers classe Utilisateur = idUtilisateur;
		public $idArticle; // Clef étrangère vers classe Article = idArticle
	}*/

	class CommentaireManager{

		public  function creer($m){
			
			$sql = "INSERT INTO Commentaire VALUES ('', ?, ?, ?, ?)";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($m->commentaire, $m->datecommentaire, $m->idUtilisateur,$m->idArticle));
			$m->id=DB::get_instance()->lastInsertId();
			return $m;
			
		}
		
		public  function chercherParID($idCommentaire){
			$sql="SELECT * from Commentaire WHERE idCommentaire=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idCommentaire));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			$m= $res->fetch();			
			$commentaire=new Commentaire();
			$commentaire->idCommentaire=$m[0];
			$commentaire->commentaire=$m[1];
			$commentaire->datecommentaire= $m[2];
			$commentaire->idUtilisateur=$m[3];
			$commentaire->idArticle=$m[4];											
			return $commentaire;
		}		
		
		public function chercherParUtilisateur($idUtilisateur){
			$sql="SELECT * from Commentaire, Utilisateur where Commentaire.idUtilisateur=Utilisateur.idUtilisateur and nomUtilisateur=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idUtilisateur));
			//gérer les erreurs éventuelles
			if ($res->rowCount()==0){
				return false;
			}
			$m= $res->fetch();
			$commentaire=new Commentaire();
			$commentaire->idCommentaire=$m[0];				// NE RENVOIE QUUN COMMENTAIRE, faire ceci: 
			$commentaire->commentaire=$m[1];                // while ($ligne = $stmt->fetch(PDO::FETCH_OBJECT)) {$data = $ligne->id . "\t" . $ligne->nom . "<br />";print $data;}
			$commentaire->datecommentaire= $m[2];
			$commentaire->idUtilisateur=$m[3];
			$commentaire->idArticle=$m[4];											
			return $commentaire;			
			}
		
		
		public function chercherparAricle($idArticle){
			$sql="SELECT * from Commentaire, Article where Commentaire.idArticle=Article.idArticle and idArticle=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idArticle));
			//gérer les erreurs éventuelles
			if ($res->rowCount()==0){
				return false;
			}			
			$m= $res->fetch();
			$commentaire=new Commentaire();
			$commentaire->idCommentaire=$m[0];				// NE RENVOIE QUUN COMMENTAIRE
			$commentaire->commentaire=$m[1];
			$commentaire->datecommentaire= $m[2];
			$commentaire->idUtilisateur=$m[3];
			$commentaire->idArticle=$m[4];											
			return $commentaire;			
			}
			
			
		public function supprimerCommentaire($idCommentaire){
		$sql="DELETE * from Commentaire where idCommentaire=?";
		$res=DB::get_instance()->prepare($sql);
		$res->execute(array($idCommentaire));
		//gérer les erreurs éventuelles
			if ($res->rowCount()==0){
				return false;
			}
		}
		

	}
	
	