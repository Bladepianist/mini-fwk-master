<?php

	class ArticleManager {

		public function creerArticle($Article){
			
			$sql = "INSERT INTO Article VALUES ('', ?, ?, ?, ?)";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array(
			$Article->titreArticle,
			$Article->contenuArticle,			
			$Article->dateArticle,			
			$Article->idUtilisateur));		
			$Article->id=DB::get_instance()->lastInsertId();
			return $Article;
		}
		
		public function chercherArticleParID($id) {
		
			$sql = "SELECT * from Article WHERE idArticle = ?";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($id));
			// Gestion d'erreurs éventuelles
			
			if($res->rowCount() == 0) {
			
				return false;
			}
			
			$Art = $res -> fetch();
			$Article = new Article();
			$Article -> idArticle = $Art[0];
			$Article -> titreArticle = $Art[1];
			$Article -> contenuArticle = $Art[2];
			$Article -> dateArticle = $Art[3];
			$Article -> idUtilisateur = $Art[4];
			return $Article;
		}
		
		public function chercherArticleParTitre($titre) {
		
			$sql = "SELECT * from Article WHERE titreArticle LIKE :recherche";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array(":recherche" => "%$titre%"));
			// Gestion d'erreurs éventuelles
			
			if($res->rowCount() == 0) {
			
				return false;
			}
			
			$Art = $res -> fetch();
			$Article = new Article();
			$Article -> idArticle = $Art[0];
			$Article -> titreArticle = $Art[1];
			$Article -> contenuArticle = $Art[2];
			$Article -> dateArticle = $Art[3];
			$Article -> idUtilisateur = $Art[4];
			return $Article;
		}
	}
	
?>