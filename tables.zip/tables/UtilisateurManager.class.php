<?php

	/*
	
	class Utilisateur {
	
		public $idUtilisateur; //Clé primaire
		public $nomUtilisateur;
		public $prenomUtilisateur;
		public $dateNaissanceUtilisateur;
		public $emailUtilisateur;
		public $dateInscription;
		public $password;
		public $idStatutUtilisateur; //Clé secondaire vers classe statutUtilisateur
		public $idNiveauUtilisateur; //Clé secondaire vers classe niveauetude
		public $idDepartement; //Clef secondaire vers classe Departement
	}
	*/
	
	
	class UtilisateurManager {

	
//----------------------------------------- Création, Suppression et Listage Utilisateurs --------------------------------------//


		public  function creer($m){
			
			$sql = "INSERT INTO Utilisateur VALUES ('', ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($m->nomUtilisateur, $m->prenomUtilisateur, $m->dateNaissanceUtilisateur,$m->emailUtilisateur, $m->dateInscription, $m->password, $m->idStatutUtilisateur, $m->idNiveauUtilisateur, $m->idDepartement));
			$m->id=DB::get_instance()->lastInsertId();
			return $m;
			
		}
		
		public function listerUtilisateur(){
			$sql="SELECT * from Utilisateur";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idUtilisateur));
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
			while ($ligne = $res->fetch(PDO::FETCH_OBJECT)) {
				$data = $ligne->idUtilisateur . "\t" . $ligne->nomUtilisateur . "\t" . 
				$ligne->prenomUtilisateur . "\t" . $ligne->dateNaissanceUtilisateur . "\t" . 
				$ligne->emailUtilisateur . "\t" . $ligne->dateInscription . "\t" . $ligne->password . "\t" .
				$ligne->idStatutUtilisateur . "\t" . $ligne-> idNiveauUtilisateur . "\t" . $ligne->idDepartement . "<br />";
				print $data;
			}
		}
		
		public function supprimerUtilisateur($idUtilisateur){
			$sql="DELETE * from Utilisateur where idUtilisateur=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idUtilisateur));
			//gérer les erreurs éventuelles
			if ($res->rowCount()==0){
				return false;
			}
		}				
		
		
//--------------------------------------------- RECHERCHES ----------------------------------------//



		public  function chercherParID($idUtilisateur){
			$sql="SELECT * from Utilisateur WHERE idUtilisateur=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idUtilisateur));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			$m= $res->fetch();			
			$utilisateur=new Utilisateur();
			$utilisateur->idUtilisateur=$m[0];
			$utilisateur->nomUtilisateur=$m[1];
			$utilisateur->prenomUtilisateur= $m[2];
			$utilisateur->dateNaissanceUtilisateur=$m[3];
			$utilisateur->emailUtilisateur=$m[4];
			$utilisateur->dateInscription=$m[5];
			$utilisateur->password=$m[6];
			$utilisateur->idStatutUtilisateur=$m[7];	
			$utilisateur->idNiveauUtilisateur=$m[8];
			$utilisateur->idDepartement=$m[9];	
			return $utilisateur;
		}	

		
		public  function chercherParNom($nomUtilisateur){
			$sql="SELECT * from Utilisateur WHERE nomUtilisateur=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($nomUtilisateur));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
			while ($ligne = $res->fetch(PDO::FETCH_OBJECT)) {
				$data = $ligne->idUtilisateur . "\t" . $ligne->nomUtilisateur . "\t" . 
				$ligne->prenomUtilisateur . "\t" . $ligne->dateNaissanceUtilisateur . "\t" . 
				$ligne->emailUtilisateur . "\t" . $ligne->dateInscription . "\t" . $ligne->password . "\t" .
				$ligne->idStatutUtilisateur . "\t" . $ligne-> idNiveauUtilisateur . "\t" . $ligne->idDepartement . "<br />";
				print $data;
			}
		
		}
		
		
		
	


		
				