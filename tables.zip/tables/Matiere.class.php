<?php

	Class Matiere {
	
		public $idMatiere; // Clef Primaire
		public $nomMatiere;
		public $coeffMatiere;
		public $idUE; // Clef �trang�re vers la classe UE;
	}
	
?>