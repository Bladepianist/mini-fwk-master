<?php

	class Semestre {
	
		public $idSemestre; // Clef Primaire
		public $nomSemestre;
		public $idStatutSemestre; // Clef étrangère vers StatutSemestre
	}
	
?>