<?php

	/*class Controle {
	
		public $idControle; // Clef Primaire
		public $typeControle;
		public $coeffControle;
	}*/
	
	
	class ControleManager {

	
//----------------------------------------- Création, Suppression et Listage Controles --------------------------------------//


		public  function creerControle($m){
			
			$sql = "INSERT INTO Controle(typeControle, coeffControle) VALUES (?, ?)";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($m->typeControle, $m->coeffControleeur));
			$m->id=DB::get_instance()->lastInsertId();
			return $m;
			
		}
		
		public  function modifierControle($m, $idControle){
			
			$sql = "UPDATE Controle SET typeControle = ?, coeffControle = ?";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($m->typeControle, $m->coeffControle));
			return $m;
			
		}
		
		public function listerControle(){
			$sql="SELECT * from Controle";
			$res=DB::get_instance()->prepare($sql);
			$res->execute();
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
		
		public function supprimerControle($idControle){
			$sql="DELETE FROM Controle WHERE idControle=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idControle));
			//gérer les erreurs éventuelles
			if ($res->rowCount()==0){
				return false;
			}
		}				
		
		
//--------------------------------------------- RECHERCHES ----------------------------------------//



		public  function chercherParID($idControle){
			$sql="SELECT * from Controle WHERE idControle=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idControle));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			$m= $res->fetch();			
			$controle=new Controle();
			$controle->idControle=$m[0];
			$controle->typeControle=$m[1];
			$controle->coeffControle= $m[2];
			return $controle;
		}

		public  function chercherParType($typeControle){
			$sql="SELECT * from Controle WHERE typeControle=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($typeControle));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
				$donnees = array();
                                $i = 0;
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
                                        $i++;
				}
				return $donnees;
		}	

		
		public  function chercherParCoeff($coeffControle){
			$sql="SELECT * from Controle WHERE coeffControle=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($coeffControle));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
	}
		
?>
	
?>