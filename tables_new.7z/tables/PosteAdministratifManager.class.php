<?php 

	/*Class PosteAdministratif {
	
		public $idPosteAdministratif; // Clef Primaire
		public $nomPosteAdministratif;
	}*/
	
	Class PosteAdministratifManager {
		
		public function listerPosteAdministratif(){
				$sql="SELECT * from PosteAdministratif";
				$res=DB::get_instance()->prepare($sql);
				$res->execute(array());
				if($res->rowCount()==0){
					return false;
				}
				// Tentative en cas de plusieurs résultats
				
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
	}	

?>