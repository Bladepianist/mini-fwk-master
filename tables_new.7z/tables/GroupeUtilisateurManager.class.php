<?php 

	/*class GroupeUtilisateur {
	
		  public $idGroupeUtilisateur; // Clef Primaire
		  public $nomGroupeUtilisateur;
		  public $idDepartement; // Clef secondaire vers Departement
	}*/
	
	Class GroupeUtilisateurManager {
		
		public function listerGroupeUtilisateur(){
				$sql="SELECT * from GroupeUtilisateur";
				$res=DB::get_instance()->prepare($sql);
				$res->execute(array());
				if($res->rowCount()==0){
					return false;
				}
				// Tentative en cas de plusieurs résultats
				
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
                
                public function chercherParDepartement($idDepartement) {
                    
                        $sql="SELECT * from GroupeUtilisateur WHERE idDepartement = ?";
				$res=DB::get_instance()->prepare($sql);
				$res->execute(array($idDepartement));
				if($res->rowCount()==0){
					return false;
				}
				// Tentative en cas de plusieurs résultats
				
				$donnees = array();
                                $i = 0;
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
                                        $i++;
				}
				return $donnees;
                }
	}
	
?>