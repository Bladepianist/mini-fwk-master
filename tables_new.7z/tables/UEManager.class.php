<?php

	Class UE {
		
		public $idUE; // Clef Primaire
		public $nomUE;
		public $idSemestre;
	}

	Class UEManager {
	
		public function listerUE(){
				$sql="SELECT * from UE";
				$res=DB::get_instance()->prepare($sql);
				$res->execute(array());
				if($res->rowCount()==0){
					return false;
				}
				// Tentative en cas de plusieurs résultats
				
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
	}	
	
?>