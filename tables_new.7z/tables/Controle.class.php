<?php

	class Controle {
	
		public $idControle; // Clef Primaire
		public $typeControle;
		public $coeffControle;
	}
	
?>