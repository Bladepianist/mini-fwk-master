<?php 

	Class PosteAdministratif {
	
		public $idPosteAdministratif; // Clef Primaire
		public $nomPosteAdministratif;
	}

?>