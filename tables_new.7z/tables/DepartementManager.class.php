<?php

		// public $idDepartement; // Clef Primaire
		// public $nomDepartement;
		
	class DepartementManager {

		public function creerDepartement($Departement){
			
			$sql = "INSERT INTO Departement VALUES ('', ?)";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($Departement->nomDepartement));		
			$Departement->id=DB::get_instance()->lastInsertId();
			return $Departement;
		}
		
		public function chercherDepartementParID($idDepartement) {
		
			$sql = "SELECT * from Departement WHERE idDepartement = ?";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($id));
			// Gestion d'erreurs �ventuelles
			
			if($res->rowCount() == 0) {
			
				return false;
			}
			
			$Art = $res -> fetch();
			$Departement = new Departement();
			$Departement -> idDepartement = $Art[0];
			$Departement -> titreDepartement = $Art[1];
			$Departement -> contenuDepartement = $Art[2];
			$Departement -> dateDepartement = $Art[3];
			$Departement -> idUtilisateur = $Art[4];
			return $Departement;
		}
		
		public function chercherDepartementParTitre($titre) {
		
			$sql = "SELECT * from Departement WHERE titreDepartement LIKE :recherche";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array(":recherche" => "%$titre%"));
			// Gestion d'erreurs �ventuelles
			
			if($res->rowCount() == 0) {
			
				return false;
			}
			
			$Art = $res -> fetch();
			$Departement = new Departement();
			$Departement -> idDepartement = $Art[0];
			$Departement -> titreDepartement = $Art[1];
			$Departement -> contenuDepartement = $Art[2];
			$Departement -> dateDepartement = $Art[3];
			$Departement -> idUtilisateur = $Art[4];
			return $Departement;
		}
		
		public function listerDepartement(){
				$sql="SELECT * from Departement";
				$res=DB::get_instance()->prepare($sql);
				$res->execute(array());
				if($res->rowCount()==0){
					return false;
				}
				// Tentative en cas de plusieurs r�sultats
				
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
	}
?>