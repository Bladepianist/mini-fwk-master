<?php

	Class UE {
		
		public $idUE; // Clef Primaire
		public $nomUE;
		public $idSemestre;
	}
	
?>