<?php

	/*class Note {
	
		public $idNote; // Clef Primaire
		public $valeurNote;
		public $dateNote;
		public $idControle; //Clé étrangère vers la classe controle
		public $idUtilisateur; // Clé étrangère vers la classe Utilisateur
		public $idMatiere; //Clé étrangère vers la classe Matière
	}*/

	class NoteManager {

	
//----------------------------------------- Création, Suppression et Listage Note --------------------------------------//


		public  function creerNote($m){
			
			$sql = "INSERT INTO Utilisateur(valeurNote, dateNote, idControle, idUtilisateur, idMatiere) VALUES (?, ?, ?, ?, ?)";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($m->valeurNote, $m->dateNote, $m->idControle, $m->idUtilisateur, $m->idMatiere));
			$m->id=DB::get_instance()->lastInsertId();
			return $m;
			
		}
		
		public  function modifierNote($m, $idNote){
			
			$sql = "UPDATE Utilisateur SET valeurNote = ?, dateNote = ?, idControle = ?, idUtilisateur = ?, idMatiere = ? WHERE idNote = ?";
			$res = DB::get_instance()->prepare($sql);
			$res -> execute(array($m->valeurNote, $m->dateNote, $m->idControle, $m->idUtilisateur, $m->idMatiere));
			return $m;
			
		}
		
		public function listerNote(){
			$sql="SELECT * from Note";
			$res=DB::get_instance()->prepare($sql);
			$res->execute();
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats

				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
		
		public function supprimerNote($idNote){
			$sql="DELETE FROM Note WHERE idNote=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idNote));
			//gérer les erreurs éventuelles
			if ($res->rowCount()==0){
				return false;
			}
		}				
		
		
//--------------------------------------------- RECHERCHES ----------------------------------------//



		public  function chercherParID($idNote){
			$sql="SELECT * from Note WHERE idNote=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idNote));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			$m= $res->fetch();			
			$note=new Utilisateur();
			$note->idNote=$m[0];
			$note->valeurNote=$m[1];
			$note->dateNote= $m[2];
			$note->idControle=$m[3];
			$note->idUtilisateur=$m[4];
			$note->idMatiere=$m[5];
			return $note;
		}

		public  function chercherParValeur($valeurNote){
			$sql="SELECT * from Note WHERE valeurNote=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($valeurNote));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			$m= $res->fetch();			
			// Tentative recherche résultats multiples
				$donnees = array();
                                $i = 0;
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
                                        $i++;
				}
				return $donnees;
		}	

		
		public  function chercherParIdUtilisateur($idUtilisateur){
			$sql="SELECT * from Note WHERE idUtilisateur=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idUtilisateur));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
				$donnees = array();
                                $i = 0;
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
                                        $i++;
				}
				return $donnees;
			}
		}
		
		public  function chercherParIdMatiere($idMatiere){
			$sql="SELECT * from Note WHERE idMatiere=?";
			$res=DB::get_instance()->prepare($sql);
			$res->execute(array($idMatiere));
			//gérer les erreurs éventuelles
			if($res->rowCount()==0){
				return false;
			}
			// Tentative en cas de plusieurs résultats
				$donnees = array();
                                $i = 0;
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
                                        $i++;
				}
				return $donnees;
			}
		}		
	}	
?>