<?php

	Class Professeur {
	
		public $idProfesseur; // Clef Primaire
		public $nomProfesseur;
		public $prenomProfesseur;
		public $emailProfesseur;
		public $idPosteAdministratif;
	}
	
?>