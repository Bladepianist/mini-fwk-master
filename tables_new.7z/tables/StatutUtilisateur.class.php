<?php

	Class StatutUtilisateur {
	
		public $idStatutUtilisateur; // Clef Primaire
		public $idNomStatutUtilisateur;
	}

?>