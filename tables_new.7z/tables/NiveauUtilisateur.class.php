<?php

	class NiveauUtilisateur {
	
		public $idNiveauUtilisateur; // Clef Primaire
		public $nomNiveauUtilisateur;
	}

?>