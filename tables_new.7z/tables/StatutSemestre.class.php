<?php

	Class StatutSemestre {
		
		public $idStatutSemestre; // Clef Primaire
		public $nomStatutSemestre;
	}
?>