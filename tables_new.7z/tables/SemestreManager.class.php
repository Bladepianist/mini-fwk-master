<?php

	/*class Semestre {
	
		public $idSemestre; // Clef Primaire
		public $nomSemestre;
		public $idStatutSemestre; // Clef étrangère vers StatutSemestre
	}*/

	Class SemestreManager {
	
		public function listerSemestre(){
				$sql="SELECT * from Semestre";
				$res=DB::get_instance()->prepare($sql);
				$res->execute(array());
				if($res->rowCount()==0){
					return false;
				}
				// Tentative en cas de plusieurs résultats
				
				$donnees = array();
				while($data = $res->fetch()) {
				
					$donnees[$data[0]] = $data[1];
				}
				return $donnees;
		}
	}	
?>